#!/usr/bin/env bash
# מייצר את תיקיות הפלטפורמה (android/ ios/ web/ ...) בתוך הפרויקט הקיים, בלי לדרוס את lib/
set -e
flutter create --platforms=android,ios,web --project-name music_manager .
flutter pub get
echo "עכשיו עדכן הרשאות לפי PLATFORM_SETUP.md ואז: flutter run"
