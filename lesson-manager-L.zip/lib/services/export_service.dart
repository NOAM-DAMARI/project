import '../models/lesson.dart';
import '../utils/helpers.dart';
import 'app_state.dart';
import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:flutter/foundation.dart';
import 'download_bytes.dart';

String lessonText(Lesson l, {bool withTranscript = false}) => [
      l.title,
      if (l.lecturer.isNotEmpty) 'מרצה: ${l.lecturer}',
      'תאריך: ${fmtDate(l.date)} · ${hebrewDate(l.date)}',
      '',
      if (l.summary.isNotEmpty) ...['סיכום:', l.summary, ''],
      if (l.points.isNotEmpty) ...['נקודות עיקריות:', ...l.points.map((e) => '• $e'), ''],
      if (l.marks.isNotEmpty) ...[
        'סימניות:',
        ...l.marks.map((m) => '${fmt(Duration(milliseconds: m.ms))} - ${m.text}'),
        '',
      ],
      if (withTranscript && l.transcript.isNotEmpty) ...[
        'תמלול:',
        ...l.transcript.map((m) => '[${fmt(Duration(milliseconds: m.ms))}] ${m.text}'),
      ],
    ].join('\n');

String _safeName(String s) => s.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');

/// שיתוף קובץ מהזיכרון – עובד בטלפון, במחשב ובדפדפן (בדפדפן הקובץ יורד)
Future<void> _shareBytes(List<int> bytes, String name, String mime, {String? text}) async {
  if (kIsWeb) {
    await downloadBytes(Uint8List.fromList(bytes), name, mime);
    return;
  }
  final file = XFile.fromData(Uint8List.fromList(bytes), name: name, mimeType: mime);
  await Share.shareXFiles([file], text: text);
}

/// בחירת פורמט ייצוא לשיעור
Future<void> exportLessonMenu(BuildContext context, Lesson l) async {
  final kind = await showModalBottomSheet<String>(
    context: context,
    showDragHandle: true,
    builder: (ctx) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(
          leading: const Icon(Icons.picture_as_pdf_rounded),
          title: const Text('קובץ PDF'),
          subtitle: const Text('סיכום, נקודות, סימניות ותמלול'),
          onTap: () => Navigator.pop(ctx, 'pdf'),
        ),
        ListTile(
          leading: const Icon(Icons.description_rounded),
          title: const Text('קובץ טקסט'),
          subtitle: const Text('סיכום ונקודות בלבד'),
          onTap: () => Navigator.pop(ctx, 'txt'),
        ),
        ListTile(
          leading: const Icon(Icons.copy_rounded),
          title: const Text('העתקה כטקסט'),
          onTap: () => Navigator.pop(ctx, 'copy'),
        ),
        const SizedBox(height: 8),
      ]),
    ),
  );
  if (kind == null) return;
  try {
    switch (kind) {
      case 'pdf':
        await exportLesson(l);
      case 'txt':
        await _shareBytes(utf8.encode(lessonText(l)), '${_safeName(l.title)}.txt', 'text/plain', text: l.title);
      case 'copy':
        await Clipboard.setData(ClipboardData(text: lessonText(l, withTranscript: true)));
        if (context.mounted) snack(context, 'הועתק');
    }
  } catch (e) {
    if (context.mounted) snack(context, 'הייצוא נכשל: $e');
  }
}

/// ייצוא שיעור ל-PDF בעברית (הפונט מצורף לאפליקציה) ושיתוף
Future<void> exportLesson(Lesson l) async {
  final text = lessonText(l, withTranscript: true);
  try {
    final font = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoSansHebrew-Regular.ttf'));
    final bold = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoSansHebrew-Bold.ttf'));
    final doc = pw.Document();
    final lines = text.split('\n');
    doc.addPage(pw.MultiPage(
      textDirection: pw.TextDirection.rtl,
      theme: pw.ThemeData.withFont(base: font, bold: bold),
      build: (_) => [
        pw.Text(lines.first, style: pw.TextStyle(font: bold, fontSize: 22)),
        pw.SizedBox(height: 8),
        ...lines.skip(1).map((e) => pw.Padding(
              padding: const pw.EdgeInsets.only(bottom: 2),
              child: pw.Text(
                e.isEmpty ? ' ' : e,
                style: e.endsWith(':') ? pw.TextStyle(font: bold, fontSize: 14) : const pw.TextStyle(fontSize: 11),
              ),
            )),
      ],
    ));
    await _shareBytes(await doc.save(), '${_safeName(l.title)}.pdf', 'application/pdf', text: l.title);
  } catch (_) {
    await Share.share(text); // גיבוי: שיתוף כטקסט (וואטסאפ / מייל)
  }
}

List<Widget> backupTiles(BuildContext c) => [
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.save_alt_rounded),
        title: const Text('גיבוי נתונים'),
        subtitle: const Text('זמרים, שירים, שיעורים, רשימות ומועדפים – לקובץ JSON'),
        onTap: () async {
          try {
            final d = DateTime.now();
            await _shareBytes(utf8.encode(app.export()), 'backup_${d.year}-${d.month}-${d.day}.json', 'application/json');
          } catch (e) {
            if (c.mounted) snack(c, 'הגיבוי נכשל: $e');
          }
        },
      ),
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.restore_rounded),
        title: const Text('שחזור מגיבוי'),
        subtitle: const Text('מחליף את כל הנתונים הנוכחיים'),
        onTap: () async {
          final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json'], withData: true);
          final bytes = r == null || r.files.isEmpty ? null : r.files.first.bytes;
          if (bytes == null) return;
          if (c.mounted && !await confirm(c, 'השחזור יחליף את כל הנתונים הנוכחיים. להמשיך?', ok: 'שחזור')) return;
          String msg;
          try {
            app.restore(utf8.decode(bytes));
            app.save();
            msg = 'הנתונים שוחזרו';
          } catch (_) {
            msg = 'קובץ גיבוי לא תקין';
          }
          if (c.mounted) snack(c, msg);
        },
      ),
    ];
