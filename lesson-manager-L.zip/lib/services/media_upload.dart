import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:flutter/foundation.dart';
import '../models/media.dart';
import '../utils/helpers.dart';
import '../utils/mp3.dart';
import 'app_state.dart';
import 'file_service.dart';
import 'github_media.dart';
import 'storage.dart';
import 'local_sync.dart';

/// מצרף קובץ שנבחר לשיר/שיעור: שומר במכשיר, ואם GitHub מחובר – מעלה עם חלון התקדמות.
/// מחזיר true אם הקובץ נשמר (גם אם רק במכשיר).
Future<bool> attachMedia(BuildContext context, MediaFields target, PickedMedia picked, {required String folder}) async {
  final oldLocal = target.filePath;
  final oldAsset = target.assetApi;

  target
    ..filePath = picked.path
    ..fileName = picked.name
    ..fileSize = picked.size
    ..remoteUrl = null
    ..assetApi = oldAsset; // נשמר כדי למחוק אחרי העלאה מוצלחת

  if (oldLocal != null && oldLocal != picked.path) deleteMedia(oldLocal).catchError((_) {});

  // עותק בתיקייה המקומית המחוברת (לא חוסם; כשל לא מבטל את השמירה)
  if (app.localEnabled && picked.path != null) {
    try {
      await copyMediaToLocal(app.localFolder, picked.path!, picked.name, folder);
    } catch (e) {
      debugPrint('local media copy failed: $e');
    }
  }

  if (!app.githubReady) {
    target.assetApi = null;
    if (kIsWeb && app.localEnabled) return false;
    if (kIsWeb && context.mounted) {
      snack(context, 'בדפדפן חובה לחבר GitHub כדי לשמור קבצים');
      return false;
    }
    return true;
  }

  try {
    await runWithProgress(context, 'מעלה את "${picked.name}"', (report) {
      return GitHubMedia.upload(picked, target, folder: folder, onProgress: report);
    });
    return true;
  } catch (e) {
    target.assetApi = null;
    if (context.mounted) {
      snack(context, 'ההעלאה ל-GitHub נכשלה – הקובץ נשמר במכשיר. אפשר לנסות שוב ממסך הקבצים.\n$e');
    }
    return picked.path != null;
  }
}

/// העלאה מאוחרת של קובץ שנשמר רק במכשיר
Future<bool> uploadExisting(BuildContext context, MediaFields target, {required String folder}) async {
  final path = target.filePath;
  final size = localFileSize(path);
  if (path == null || size == null) {
    snack(context, 'הקובץ לא נמצא במכשיר');
    return false;
  }
  try {
    await runWithProgress(context, 'מעלה את "${target.fileName ?? 'הקובץ'}"', (report) {
      return GitHubMedia.upload(PickedMedia(path: path, name: target.fileName ?? 'audio', size: size), target,
          folder: folder, onProgress: report);
    });
    return true;
  } catch (e) {
    if (context.mounted) snack(context, 'ההעלאה נכשלה: $e');
    return false;
  }
}

/// זיהוי משך הקובץ (כל פורמט שהנגן תומך בו; גיבוי – חישוב מכותרת MP3)
Future<Duration?> probeDuration(PickedMedia m) async {
  if (m.path != null) {
    final probe = AudioPlayer();
    try {
      final d = await probe.setFilePath(m.path!).timeout(const Duration(seconds: 8));
      if (d != null && d > Duration.zero) return d;
    } catch (_) {
    } finally {
      probe.dispose();
    }
    final head = await readLocalRange(m.path!, 0, m.size < 65536 ? m.size : 65536);
    return estimateMp3Duration(head, m.size);
  }
  if (m.bytes != null) return estimateMp3Duration(m.bytes!.take(65536).toList(), m.size);
  return null;
}

String formatDuration(Duration d) => d.inHours > 0
    ? '${d.inHours}:${(d.inMinutes % 60).toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}'
    : '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
