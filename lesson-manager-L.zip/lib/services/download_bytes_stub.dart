import 'dart:typed_data';

Future<void> downloadBytes(Uint8List bytes, String name, String mime) async {}
Future<void> openDownloadUrl(String url, String name) async {}
