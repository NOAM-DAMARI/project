import '../models/playlist.dart';
import '../models/lesson.dart';
import '../models/singer.dart';
import '../models/song.dart';
import 'file_service.dart';
import 'github_media.dart';
import 'local_sync.dart';

import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class AppState extends ChangeNotifier {
  late SharedPreferences _p;
  SharedPreferences get prefs => _p;

  List<Singer> singers = [];
  List<Song> songs = [];
  List<Lesson> lessons = [];
  List<Playlist> playlists = [];

  bool dark = false;
  final darkMode = ValueNotifier<bool>(false);

  String githubOwner = 'NOAM-DAMARI';
  String githubRepo = 'musicmanagerupdated';
  String githubBranch = 'main';
  String githubToken = '';

  bool githubEnabled = false;
  bool localEnabled = false;
  String localFolder = '';
  bool syncing = false;
  String syncMessage = 'לא מחובר ל-GitHub';
  DateTime? lastSync;

  String? livePointLessonId;
  int? livePointIndex;

  /// יש שינויים מקומיים שעדיין לא נשמרו ב-GitHub
  bool _dirty = false;

  Future<void> _syncQueue = Future<void>.value();
  Timer? _pushTimer;

  bool get githubReady => githubEnabled && githubToken.isNotEmpty;

  String get githubApiBase => 'https://api.github.com/repos/$githubOwner/$githubRepo/contents';

  String get githubUrl => '$githubApiBase/data/music_manager.json';

  String githubRawUrl(String path) =>
      'https://raw.githubusercontent.com/$githubOwner/$githubRepo/$githubBranch/$path';

  Map<String, String> get githubHeaders => {
        'Accept': 'application/vnd.github+json',
        'Authorization': 'Bearer $githubToken',
        'X-GitHub-Api-Version': '2022-11-28',
      };

  Map<String, String> get _headers => {...githubHeaders, 'Content-Type': 'application/json'};

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();

    dark = _p.getBool('dark') ?? false;
    darkMode.value = dark;
    githubOwner = _p.getString('githubOwner') ?? githubOwner;
    githubRepo = _p.getString('githubRepo') ?? githubRepo;
    githubBranch = _p.getString('githubBranch') ?? githubBranch;
    githubToken = _p.getString('githubToken') ?? '';
    githubEnabled = _p.getBool('githubEnabled') ?? false;
    localFolder = _p.getString('localFolder') ?? '';
    localEnabled = localFolder.isNotEmpty;
    _dirty = _p.getBool('dirty') ?? false;

    final raw = _p.getString('data');
    if (raw != null) {
      try {
        restore(raw);
      } catch (_) {
        syncMessage = 'הנתונים המקומיים אינם תקינים';
      }
    }
    if (localEnabled && !_dirty) {
      try {
        final folderRaw = await readLocalJson(localFolder);
        if (folderRaw != null && folderRaw.trim().isNotEmpty) {
          restore(folderRaw);
          await _p.setString('data', folderRaw);
        }
      } catch (_) {
        syncMessage = 'לא ניתן לקרוא את תיקיית הסנכרון המקומית';
      }
    }

    if (githubReady) {
      // הסנכרון רץ ברקע כדי שהאפליקציה תיפתח מיד גם בלי אינטרנט
      unawaited(syncNow());
    }

    notifyListeners();
  }

  String export() => jsonEncode({
        'singers': singers,
        'songs': songs,
        'lessons': lessons,
        'playlists': playlists,
      });

  void restore(String raw) {
    final d = jsonDecode(raw);

    singers = (d['singers'] as List? ?? []).map((e) => Singer.fromJson(e)).toList();
    songs = (d['songs'] as List? ?? []).map((e) => Song.fromJson(e)).toList();
    lessons = (d['lessons'] as List? ?? []).map((e) => Lesson.fromJson(e)).toList();
    playlists = (d['playlists'] as List? ?? []).map((e) => Playlist.fromJson(e)).toList();
  }

  void _setDirty(bool v) {
    _dirty = v;
    _p.setBool('dirty', v);
  }

  Timer? _diskTimer;
  Future<void> _diskQueue = Future<void>.value();
  bool _notifyScheduled = false;

  /// שמירה: מעדכנת את המסך מיד, כותבת לדיסק אחרי 400ms של שקט (כתיבה אחת ולא עשרות),
  /// ומעלה ל-GitHub אחרי 2 שניות. כך הקלדה לא תוקעת את האפליקציה.
  /// [notify]=false – לשדות טקסט שלא צריכים לבנות את המסך מחדש בכל הקשה.
  void save({bool notify = true}) {
    _diskTimer?.cancel();
    _diskTimer = Timer(const Duration(milliseconds: 400), flushNow);
    if (notify) _scheduleNotify();

    if (githubReady) {
      _setDirty(true);
      _pushTimer?.cancel();
      _pushTimer = Timer(const Duration(seconds: 2), _queuePush);
    }
  }

  /// כתיבה מיידית לדיסק (נקרא גם כשהאפליקציה עוברת לרקע). כתיבות לא חופפות.
  Future<void> flushNow() {
    _diskTimer?.cancel();
    final raw = export();
    _diskQueue = _diskQueue.catchError((_) {}).then((_) async {
      try {
        await _p.setString('data', raw);
      } catch (e) {
        debugPrint('preferences save failed: $e');
      }
      if (localEnabled) {
        try {
          await writeLocalJson(localFolder, raw);
        } catch (e) {
          syncMessage = 'שמירה לתיקייה המקומית נכשלה: ${_short(e)}';
        }
      }
    });
    return _diskQueue;
  }

  /// מאחד עדכוני מסך ולא קורא ל-notifyListeners באמצע בניית מסך (מונע לולאות Rebuild).
  void _scheduleNotify() {
    if (_notifyScheduled) return;
    _notifyScheduled = true;
    void run() {
      _notifyScheduled = false;
      notifyListeners();
    }
    final phase = SchedulerBinding.instance.schedulerPhase;
    if (phase == SchedulerPhase.persistentCallbacks || phase == SchedulerPhase.midFrameMicrotasks) {
      SchedulerBinding.instance.addPostFrameCallback((_) => run());
    } else {
      scheduleMicrotask(run);
    }
  }

  void _queuePush() {
    _syncQueue = _syncQueue.catchError((_) {}).then((_) async {
      try {
        await pushToGitHub();
      } catch (e) {
        syncMessage = 'שגיאת סנכרון: ${_short(e)}';
      }
      notifyListeners();
    });
  }

  Future<void> configureGitHub({
    required String owner,
    required String repo,
    required String branch,
    required String token,
  }) async {
    githubOwner = owner.trim();
    githubRepo = repo.trim();
    githubBranch = branch.trim().isEmpty ? 'main' : branch.trim();
    githubToken = token.trim();
    githubEnabled = true;

    await _p.setString('githubOwner', githubOwner);
    await _p.setString('githubRepo', githubRepo);
    await _p.setString('githubBranch', githubBranch);
    await _p.setString('githubToken', githubToken);
    await _p.setBool('githubEnabled', true);

    notifyListeners();
    await syncNow();
  }

  Future<void> configureLocalFolder(String folder) async {
    final f = folder.trim();
    if (f.isNotEmpty) await checkLocalFolderWritable(f);
    localFolder = f;
    localEnabled = localFolder.isNotEmpty;
    // אם בתיקייה כבר יש נתונים ואין כאן נתונים – טוענים מהתיקייה במקום לדרוס
    if (localEnabled && singers.isEmpty && songs.isEmpty && lessons.isEmpty) {
      final existing = await readLocalJson(localFolder);
      if (existing != null && existing.trim().length > 2) {
        restore(existing);
        await _p.setString('localFolder', localFolder);
        await _p.setString('data', existing);
        _scheduleNotify();
        return;
      }
    }
    await _p.setString('localFolder', localFolder);
    if (localEnabled) await writeLocalJson(localFolder, export());
    notifyListeners();
  }

  Future<void> disconnectLocalFolder() async {
    localFolder = '';
    localEnabled = false;
    await _p.remove('localFolder');
    notifyListeners();
  }

  Future<void> disconnectGitHub() async {
    githubEnabled = false;
    githubToken = '';

    await _p.setBool('githubEnabled', false);
    await _p.remove('githubToken');

    syncMessage = 'החיבור ל-GitHub נותק';
    notifyListeners();
  }

  Future<void> syncNow() async {
    if (!githubReady) {
      syncMessage = 'יש להגדיר חיבור ל-GitHub';
      notifyListeners();
      return;
    }
    if (syncing) return;

    syncing = true;
    syncMessage = 'מסנכרן...';
    notifyListeners();

    try {
      await ensureRepositoryStructure();
      if (_dirty) {
        // יש שינויים שנעשו בלי אינטרנט – מעלים אותם במקום לדרוס אותם
        await pushToGitHub();
      } else {
        final found = await pullFromGitHub();
        if (!found) await pushToGitHub();
      }
      lastSync = DateTime.now();
      syncMessage = 'הסנכרון הסתיים בהצלחה';
    } catch (e) {
      syncMessage = 'שגיאה: ${_short(e)}';
    } finally {
      syncing = false;
      notifyListeners();
    }
  }

  Future<bool> pullFromGitHub() async {
    final uri = Uri.parse(githubUrl).replace(queryParameters: {'ref': githubBranch});
    final response = await http.get(uri, headers: _headers);

    if (response.statusCode == 404) return false;
    if (response.statusCode != 200) {
      throw Exception('GitHub GET ${response.statusCode}: ${response.body}');
    }

    final result = jsonDecode(response.body);
    final content = (result['content'] as String).replaceAll('\n', '');
    final raw = utf8.decode(base64Decode(content));
    if (raw.trim() == '{}' || raw.trim().isEmpty) return false;

    restore(raw);
    await _p.setString('data', raw);
    return true;
  }

  /// העלאת קובץ קטן (תמונת זמר) דרך Contents API.
  Future<String> uploadMediaBytes({
    required String fileName,
    required List<int> bytes,
    String folder = 'songs',
  }) async {
    if (!githubReady) throw Exception('יש להגדיר חיבור ל-GitHub לפני העלאת קובץ');
    if (bytes.length > 50 * 1024 * 1024) throw Exception('קובץ גדול מדי לתמונה');

    final safeName = fileName.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_');
    final path = 'media/$folder/${DateTime.now().millisecondsSinceEpoch}_$safeName';
    final uri = Uri.parse('$githubApiBase/$path');
    final response = await http.put(
      uri,
      headers: _headers,
      body: jsonEncode({
        'message': 'העלאת מדיה: $safeName',
        'content': base64Encode(bytes),
        'branch': githubBranch,
      }),
    );

    if (response.statusCode != 200 && response.statusCode != 201) {
      throw Exception('GitHub media PUT ${response.statusCode}: ${response.body}');
    }
    return path;
  }

  Future<void> ensureRepositoryStructure() async {
    for (final path in ['data/music_manager.json', 'media/singers/.gitkeep']) {
      final uri = Uri.parse('$githubApiBase/$path');
      final existing = await http.get(uri.replace(queryParameters: {'ref': githubBranch}), headers: _headers);
      if (existing.statusCode == 200) continue;
      if (existing.statusCode != 404) {
        throw Exception('GitHub GET ${existing.statusCode}: ${existing.body}');
      }
      await http.put(
        uri,
        headers: _headers,
        body: jsonEncode({
          'message': 'יצירת מבנה Music Manager',
          'content': base64Encode(utf8.encode(path.endsWith('.json') ? '{}' : '')),
          'branch': githubBranch,
        }),
      );
    }
  }

  Future<void> pushToGitHub() async {
    if (!githubReady) return;

    final uri = Uri.parse(githubUrl);
    String? sha;

    final getResponse = await http.get(uri.replace(queryParameters: {'ref': githubBranch}), headers: _headers);

    if (getResponse.statusCode == 200) {
      sha = jsonDecode(getResponse.body)['sha'];
    } else if (getResponse.statusCode != 404) {
      throw Exception('GitHub GET ${getResponse.statusCode}: ${getResponse.body}');
    }

    final body = <String, dynamic>{
      'message': 'עדכון נתוני Music Manager',
      'content': base64Encode(utf8.encode(export())),
      'branch': githubBranch,
    };
    if (sha != null) body['sha'] = sha;

    final response = await http.put(uri, headers: _headers, body: jsonEncode(body));

    if (response.statusCode != 200 && response.statusCode != 201) {
      throw Exception('GitHub PUT ${response.statusCode}: ${response.body}');
    }

    _setDirty(false);
    lastSync = DateTime.now();
    syncMessage = 'הנתונים נשמרו ב-GitHub';
  }

  void setDark(bool v) {
    dark = v;
    darkMode.value = v;
    _p.setBool('dark', v);
    notifyListeners();
  }

  Singer? singer(String id) {
    for (final s in singers) {
      if (s.id == id) return s;
    }
    return null;
  }

  Song? songById(String id) {
    for (final s in songs) {
      if (s.id == id) return s;
    }
    return null;
  }

  Lesson? lessonById(String id) {
    for (final l in lessons) {
      if (l.id == id) return l;
    }
    return null;
  }

  /// רשימת המרצים לבחירה: שמות שנשמרו ידנית + שמות שכבר מופיעים בשיעורים.
  List<String> get lecturers {
    final saved = _p.getStringList('lecturers') ?? const <String>[];
    final hidden = (_p.getStringList('lecturersHidden') ?? const <String>[]).toSet();
    final all = <String>{...saved, ...lessons.map((l) => l.lecturer.trim()).where((x) => x.isNotEmpty)}
      ..removeAll(hidden);
    return all.toList()..sort();
  }

  void addLecturer(String name) {
    final n = name.trim();
    if (n.isEmpty) return;
    final saved = {...?_p.getStringList('lecturers'), n};
    final hidden = {...?_p.getStringList('lecturersHidden')}..remove(n);
    _p.setStringList('lecturers', saved.toList());
    _p.setStringList('lecturersHidden', hidden.toList());
    _scheduleNotify();
  }

  void removeLecturer(String name) {
    final saved = {...?_p.getStringList('lecturers')}..remove(name);
    final hidden = {...?_p.getStringList('lecturersHidden'), name};
    _p.setStringList('lecturers', saved.toList());
    _p.setStringList('lecturersHidden', hidden.toList());
    _scheduleNotify();
  }

  void renameLecturer(String from, String to) {
    final t = to.trim();
    if (t.isEmpty || t == from) return;
    for (final l in lessons) {
      if (l.lecturer.trim() == from) l.lecturer = t;
    }
    removeLecturer(from);
    addLecturer(t);
    save();
  }

  String newId() => DateTime.now().microsecondsSinceEpoch.toString();

  /// מחיקת הקבצים (מקומי + ענן) – לא חוסם את הממשק
  void _dropFiles(String? localPath, String? assetApi) {
    deleteMedia(localPath).catchError((_) {});
    if (assetApi != null && githubReady) GitHubMedia.deleteAsset(assetApi).catchError((_) {});
  }

  void deleteSinger(Singer s) {
    for (final song in songs.where((x) => x.singerId == s.id).toList()) {
      _removeSong(song);
    }
    singers.remove(s);
    save();
  }

  void _removeSong(Song s) {
    _dropFiles(s.filePath, s.assetApi);
    songs.remove(s);
    for (final p in playlists) {
      p.songIds.remove(s.id);
    }
  }

  void deleteSong(Song s) {
    _removeSong(s);
    save();
  }

  void deleteLesson(Lesson l) {
    _dropFiles(l.filePath, l.assetApi);
    _p.remove('pos_${l.id}');
    lessons.remove(l);
    save();
  }

  static String _short(Object e) {
    final s = e.toString().replaceFirst('Exception: ', '');
    return s.length > 160 ? '${s.substring(0, 160)}…' : s;
  }
}

final app = AppState();
