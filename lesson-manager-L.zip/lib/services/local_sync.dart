export 'local_sync_stub.dart' if (dart.library.io) 'local_sync_io.dart';
