import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'storage.dart';

const audioExts = ['mp3', 'm4a', 'wav', 'aac', 'ogg', 'opus', 'flac', 'mp4', 'mov', 'mkv', 'webm'];

class PickedMedia {
  /// עותק קבוע במכשיר (null בדפדפן)
  final String? path;
  final String name;
  final int size;

  /// תוכן הקובץ – רק בדפדפן או כשביקשו במפורש (תמונות)
  final Uint8List? bytes;

  PickedMedia({required this.path, required this.name, required this.size, this.bytes});
}

/// בחירת קובץ. בטלפון הקובץ מועתק לאחסון האפליקציה בלי לטעון אותו לזיכרון,
/// כך שאפשר לבחור גם קבצים של מאות MB.
Future<PickedMedia?> pickMedia(FileType type, {List<String>? exts, bool needBytes = false}) async {
  final result = await FilePicker.platform.pickFiles(
    type: type,
    // file_picker זורק שגיאה אם מעבירים סיומות לסוג שאינו custom
    allowedExtensions: type == FileType.custom ? exts : null,
    withData: kIsWeb || needBytes,
    allowMultiple: false,
  );
  if (result == null || result.files.isEmpty) return null;
  final file = result.files.first;

  if (kIsWeb) {
    if (file.bytes == null || file.bytes!.isEmpty) return null;
    return PickedMedia(path: null, name: file.name, size: file.bytes!.length, bytes: file.bytes);
  }

  String? path;
  if (file.path != null) {
    path = await persistPickedFile(file.path!, file.name);
  } else if (file.bytes != null) {
    path = await persistPickedBytes(file.name, file.bytes!);
  }
  if (path == null) return null;
  return PickedMedia(path: path, name: file.name, size: file.size, bytes: file.bytes);
}

Future<PickedMedia?> pickAudio() => pickMedia(FileType.custom, exts: audioExts);

Future<void> deleteMedia(String? path) => deletePersistedFile(path);
