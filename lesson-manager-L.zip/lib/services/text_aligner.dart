import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../models/lesson.dart';

/// התאמת טקסט חופשי לזמני תמלול קיים – בלי לשנות אף אות בטקסט המקור.
///
/// ההשוואה סלחנית: מתעלמת מניקוד וטעמים, סימני פיסוק, אותיות סופיות,
/// ומאפשרת שגיאת אות אחת במילים ארוכות. ההתאמה מונוטונית (הטקסט מתקדם רק קדימה בזמן),
/// כך שגם קטעים שלא זוהו מקבלים זמן משוער בין השכנים שלהם.
class TextAligner {
  static final _niqqud = RegExp(r'[\u0591-\u05C7]');
  static final _punct = RegExp(r'''[^\p{L}\p{N}]''', unicode: true);
  static const _finals = {'ך': 'כ', 'ם': 'מ', 'ן': 'נ', 'ף': 'פ', 'ץ': 'צ'};

  static String norm(String w) {
    var s = w.toLowerCase().replaceAll(_niqqud, '').replaceAll(_punct, '');
    final b = StringBuffer();
    for (final ch in s.split('')) {
      b.write(_finals[ch] ?? ch);
    }
    return b.toString();
  }

  static bool _similar(String a, String b) {
    if (a == b) return true;
    if (a.length < 4 || b.length < 4) return false;
    if ((a.length - b.length).abs() > 1) return false;
    // מרחק עריכה ≤ 1
    var i = 0, j = 0, edits = 0;
    while (i < a.length && j < b.length) {
      if (a[i] == b[j]) {
        i++;
        j++;
        continue;
      }
      if (++edits > 1) return false;
      if (a.length > b.length) {
        i++;
      } else if (b.length > a.length) {
        j++;
      } else {
        i++;
        j++;
      }
    }
    return edits + (a.length - i) + (b.length - j) <= 1;
  }

  /// מחזיר שורה לכל שורה לא ריקה בטקסט, עם זמן התחלה מדויק ככל האפשר.
  static List<Seg> align(String text, List<Seg> transcript, {int? totalMs}) {
    final lines = text.split(RegExp(r'\r?\n')).map((e) => e.trimRight()).where((e) => e.trim().isNotEmpty).toList();
    if (lines.isEmpty) return [];
    if (transcript.isEmpty) return [for (final l in lines) Seg(0, l)];

    // מילים מהתמלול עם זמן משוער לכל מילה (פריסה לינארית בתוך הקטע)
    final tWords = <String>[];
    final tTimes = <int>[];
    final lastMs = totalMs ?? (transcript.last.ms + 4000);
    for (var k = 0; k < transcript.length; k++) {
      final start = transcript[k].ms;
      final end = k + 1 < transcript.length ? transcript[k + 1].ms : lastMs;
      final words = transcript[k].text.split(RegExp(r'\s+')).map(norm).where((w) => w.isNotEmpty).toList();
      for (var w = 0; w < words.length; w++) {
        tWords.add(words[w]);
        tTimes.add(start + ((end - start) * w / words.length).round());
      }
    }
    if (tWords.isEmpty) return [for (final l in lines) Seg(0, l)];

    final lineTimes = List<int?>.filled(lines.length, null);
    var j = 0;
    var misses = 0;
    for (var li = 0; li < lines.length; li++) {
      final words = lines[li].split(RegExp(r'\s+')).map(norm).where((w) => w.isNotEmpty).toList();
      for (var wi = 0; wi < words.length; wi++) {
        final w = words[wi];
        final window = misses > 25 ? 800 : 80;
        var found = -1;
        for (var k = j; k < tWords.length && k < j + window; k++) {
          if (_similar(w, tWords[k])) {
            // בחלון רחב דורשים אישור מהמילה הבאה כדי לא לקפוץ למקום שגוי
            if (window > 80 && wi + 1 < words.length && k + 1 < tWords.length && !_similar(words[wi + 1], tWords[k + 1])) {
              continue;
            }
            found = k;
            break;
          }
        }
        if (found >= 0) {
          lineTimes[li] ??= tTimes[found];
          j = found + 1;
          misses = 0;
        } else {
          misses++;
        }
      }
    }

    // השלמת שורות שלא זוהו: אינטרפולציה בין השכנים
    final result = <Seg>[];
    for (var li = 0; li < lines.length; li++) {
      var t = lineTimes[li];
      if (t == null) {
        var prev = li - 1;
        while (prev >= 0 && lineTimes[prev] == null) {
          prev--;
        }
        var next = li + 1;
        while (next < lines.length && lineTimes[next] == null) {
          next++;
        }
        final a = prev >= 0 ? lineTimes[prev]! : 0;
        final b = next < lines.length ? lineTimes[next]! : lastMs;
        final pa = prev >= 0 ? prev : -1;
        final pb = next < lines.length ? next : lines.length;
        t = a + ((b - a) * (li - pa) / (pb - pa)).round();
      }
      if (result.isNotEmpty && t < result.last.ms) t = result.last.ms;
      result.add(Seg(t, lines[li]));
    }
    return result;
  }
}

/// חלון קבלת טקסט: הדבקה או בחירת קובץ txt. מחזיר את הטקסט כפי שהוא.
Future<String?> askTextForAlignment(BuildContext context, {String title = 'העלאת טקסט וסידור לפי זמנים'}) async {
  final ctl = TextEditingController();
  final res = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: SizedBox(
        width: 560,
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('הדבק את הטקסט המדויק (שורה לכל קטע) או בחר קובץ. הטקסט יישמר אות באות, רק יקבל זמנים.'),
          const SizedBox(height: 10),
          TextField(
            controller: ctl,
            minLines: 8,
            maxLines: 14,
            decoration: const InputDecoration(hintText: 'הדבק כאן טקסט...', alignLabelWithHint: true),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.upload_file_rounded),
              label: const Text('בחירת קובץ טקסט'),
              onPressed: () async {
                final r = await FilePicker.platform
                    .pickFiles(type: FileType.custom, allowedExtensions: ['txt', 'md', 'srt'], withData: true);
                final bytes = r?.files.firstOrNull?.bytes;
                if (bytes != null) ctl.text = utf8.decode(bytes, allowMalformed: true);
              },
            ),
          ),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ביטול')),
        FilledButton(onPressed: () => Navigator.pop(ctx, ctl.text), child: const Text('סידור לפי זמנים')),
      ],
    ),
  );
  ctl.dispose();
  if (res == null || res.trim().isEmpty) return null;
  return res;
}
