import 'media.dart';

class Seg {
  int ms;
  String text;
  Seg(this.ms, this.text);
  Map toJson() => {'ms': ms, 'text': text};
  factory Seg.fromJson(Map j) => Seg((j['ms'] as num?)?.toInt() ?? 0, j['text'] ?? '');
}

/// גרסת תמלול שמורה (ממנוע מסוים), לצורך השוואה בין מנועים.
class TranscriptVersion {
  String id, providerId, label;
  DateTime created;
  List<Seg> segs;
  TranscriptVersion({required this.id, required this.providerId, required this.label, DateTime? created, List<Seg>? segs})
      : created = created ?? DateTime.now(),
        segs = segs ?? [];

  Map toJson() => {
        'id': id,
        'providerId': providerId,
        'label': label,
        'created': created.toIso8601String(),
        'segs': segs,
      };

  factory TranscriptVersion.fromJson(Map j) => TranscriptVersion(
        id: j['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
        providerId: j['providerId']?.toString() ?? '',
        label: j['label']?.toString() ?? 'תמלול',
        created: DateTime.tryParse(j['created']?.toString() ?? ''),
        segs: ((j['segs'] ?? []) as List).map((e) => Seg.fromJson(e)).toList(),
      );
}

class Lesson with MediaFields {
  String id, title, lecturer, notes, summary;
  bool fav = false;
  DateTime date, added;
  List<String> points = [];
  List<String> pointNotes = [];
  List<Seg> pointTimes = [];
  /// End time in milliseconds for each point, when the user defines a range.
  List<int> pointEnds = [];
  List<Seg> marks = [], transcript = [];
  /// כל התמלולים שנעשו לשיעור (ממנועים שונים). [transcript] הוא התמלול הראשי.
  List<TranscriptVersion> transcripts = [];

  Lesson({
    required this.id,
    required this.title,
    this.lecturer = '',
    this.notes = '',
    this.summary = '',
    DateTime? date,
  })  : date = date ?? DateTime.now(),
        added = DateTime.now();

  Map toJson() => {
        'id': id,
        'title': title,
        'lecturer': lecturer,
        'notes': notes,
        'summary': summary,
        'fav': fav,
        'date': date.toIso8601String(),
        'added': added.toIso8601String(),
        'points': points,
        'pointNotes': pointNotes,
        'pointTimes': pointTimes,
        'pointEnds': pointEnds,
        'marks': marks,
        'transcript': transcript,
        'transcripts': transcripts,
        ...mediaJson(),
      };

  factory Lesson.fromJson(Map j) => Lesson(
        id: j['id'],
        title: j['title'] ?? '',
        lecturer: j['lecturer'] ?? '',
        notes: j['notes'] ?? '',
        summary: j['summary'] ?? '',
        date: DateTime.tryParse(j['date'] ?? ''),
      )
        ..fav = j['fav'] == true
        ..added = DateTime.tryParse(j['added'] ?? '') ?? DateTime.now()
        ..points = List<String>.from(j['points'] ?? [])
        ..pointNotes = List<String>.from(j['pointNotes'] ?? [])
        ..pointTimes = ((j['pointTimes'] ?? []) as List).map((e) => Seg.fromJson(e)).toList()
        ..pointEnds = List<int>.from((j['pointEnds'] ?? []) as List)
        ..marks = ((j['marks'] ?? []) as List).map((e) => Seg.fromJson(e)).toList()
        ..transcript = ((j['transcript'] ?? []) as List).map((e) => Seg.fromJson(e)).toList()
        ..transcripts = ((j['transcripts'] ?? []) as List).map((e) => TranscriptVersion.fromJson(e)).toList()
        ..readMedia(j);
}
