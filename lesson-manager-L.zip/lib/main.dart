import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'screens/shell.dart';
import 'services/app_state.dart';
import 'services/storage.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initStorage();
  await app.load();
  // שמירה מיידית כשהאפליקציה עוברת לרקע/נסגרת
  AppLifecycleListener(onStateChange: (s) {
    if (s == AppLifecycleState.paused || s == AppLifecycleState.inactive || s == AppLifecycleState.detached) {
      app.flushNow();
    }
  });
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  // מאזינים רק למצב כהה – לא לכל שמירה. האזנה ל-app כולו בנתה את כל האפליקציה מחדש בכל הקשה.
  Widget build(BuildContext context) => ValueListenableBuilder<bool>(
        valueListenable: app.darkMode,
        builder: (_, dark, __) => MaterialApp(
          title: 'ניהול שירים',
          debugShowCheckedModeBanner: false,
          locale: const Locale('he'),
          supportedLocales: const [Locale('he'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          scrollBehavior: const MaterialScrollBehavior().copyWith(scrollbars: true),
          themeMode: dark ? ThemeMode.dark : ThemeMode.light,
          theme: AppTheme.light(),
          darkTheme: AppTheme.dark(),
          home: const Shell(),
        ),
      );
}
