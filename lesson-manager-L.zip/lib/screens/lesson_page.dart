import 'dart:convert';

import '../models/lesson.dart';
import '../services/app_state.dart';
import '../services/export_service.dart';
import '../services/player_service.dart';
import '../services/transcriber.dart';
import '../utils/helpers.dart';
import '../widgets/player_controls.dart';
import '../widgets/seg_list.dart';
import '../widgets/point_dialog.dart';
import '../services/points.dart';
import '../services/text_aligner.dart';
import 'lesson_form.dart';
import 'settings_screen.dart';
import 'transcripts_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';

class LessonPage extends StatefulWidget {
  final Lesson l;
  final int initialTab;
  const LessonPage(this.l, {super.key, this.initialTab = 0});
  @override
  State<LessonPage> createState() => _LessonPageState();
}

class _LessonPageState extends State<LessonPage> {
  Lesson get l => widget.l;
  late final summary = TextEditingController(text: l.summary);
  bool busy = false;
  String status = '';

  Track get track => Track.lesson(l);

  @override
  void initState() {
    super.initState();
    player.markFullScreen(l.id, true);
  }

  @override
  void dispose() {
    player.markFullScreen(l.id, false);
    summary.dispose();
    super.dispose();
  }

  void changed() {
    app.save();
    setState(() {});
  }

  Future<void> transcribe() async {
    if (!l.hasMedia) {
      snack(context, 'יש להעלות קודם הקלטה לשיעור');
      return;
    }
    if (!Transcriber.ready) {
      snack(context, 'יש להשלים את הגדרות התמלול');
      go(context, const SettingsScreen(standalone: true));
      return;
    }
    if (l.transcript.isNotEmpty && !await confirm(context, 'להחליף את התמלול הקיים בתמלול חדש?', ok: 'החלפה')) return;
    setState(() {
      busy = true;
      status = 'מתחיל...';
    });
    try {
      final segs = await Transcriber.transcribe(l, onStatus: (s) {
        if (mounted) setState(() => status = s);
      });
      preserveMainTranscript(l);
      addTranscriptVersion(l, Transcriber.providerId, segs);
      l.transcript = [for (final x in segs) Seg(x.ms, x.text)];
      app.save();
      if (mounted) snack(context, 'התמלול הסתיים – לחיצה על שורה קופצת לרגע הזה בהקלטה');
    } catch (e) {
      if (mounted) snack(context, 'התמלול נכשל: ${e.toString().replaceFirst('Exception: ', '')}');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> alignTextWithAI() async {
    if (l.transcript.isEmpty) {
      snack(context, 'יש ליצור תמלול לפני התאמת AI');
      return;
    }
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['txt'], withData: true);
    if (result == null || result.files.isEmpty || result.files.first.bytes == null) return;
    setState(() { busy = true; status = 'AI מתאים את הטקסט לזמנים...'; });
    try {
      final text = utf8.decode(result.files.first.bytes!, allowMalformed: true);
      final aligned = await Transcriber.alignTextWithAI(text, l.transcript);
      if (aligned.isEmpty) throw Exception('לא התקבלו שורות מה-AI');
      l.transcript = aligned;
      app.save();
      if (mounted) snack(context, 'הטקסט הותאם לזמנים באמצעות AI');
    } catch (e) {
      if (mounted) snack(context, 'התאמת AI נכשלה: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> alignTextByTime() async {
    if (l.transcript.isEmpty) {
      snack(context, 'יש ליצור תמלול לפני סידור הטקסט – הזמנים נלקחים מהתמלול');
      return;
    }
    final text = await askTextForAlignment(context);
    if (text == null || !mounted) return;
    final aligned = TextAligner.align(text, l.transcript, );
    if (aligned.isEmpty) return;
    l.transcript = aligned;
    changed();
    snack(context, 'הטקסט סודר לפי הזמנים בלי לשנות אף אות (${aligned.length} שורות)');
  }

  Future<void> editAsText() async {
    final ctl = TextEditingController(text: l.transcript.map((s) => s.text).join('\n'));
    final res = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('עריכת התמלול'),
        content: SizedBox(
          width: 520,
          child: TextField(
            controller: ctl,
            maxLines: 16,
            minLines: 8,
            decoration: const InputDecoration(hintText: 'שורה לכל קטע. אפשר גם להדביק תמלול מוכן.'),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ביטול')),
          FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(0, 40)),
              onPressed: () => Navigator.pop(ctx, ctl.text),
              child: const Text('שמירה')),
        ],
      ),
    );
    ctl.dispose();
    if (res == null) return;
    final rows = res.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    // שומרים את הזמנים הקיימים לפי סדר השורות
    final old = l.transcript;
    l.transcript = [
      for (var i = 0; i < rows.length; i++) Seg(i < old.length ? old[i].ms : (old.isEmpty ? 0 : old.last.ms), rows[i]),
    ];
    changed();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (context, _) {
          final c = Theme.of(context).colorScheme;
          return DefaultTabController(
            initialIndex: widget.initialTab < 0 ? 0 : (widget.initialTab > 3 ? 3 : widget.initialTab),
            length: 4,
            child: Scaffold(
              appBar: AppBar(
                title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(l.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  Text([if (l.lecturer.isNotEmpty) l.lecturer, fmtDate(l.date), hebrewDate(l.date)].join(' · '),
                      style: TextStyle(fontSize: 12, color: c.onSurfaceVariant)),
                ]),
                actions: [
                  IconButton(
                    tooltip: l.fav ? 'הסרה ממועדפים' : 'הוספה למועדפים',
                    icon: Icon(l.fav ? Icons.star_rounded : Icons.star_outline_rounded,
                        color: l.fav ? const Color(0xFFF2A541) : null),
                    onPressed: () {
                      l.fav = !l.fav;
                      app.save();
                    },
                  ),
                  IconButton(
                      icon: const Icon(Icons.ios_share_rounded), tooltip: 'ייצוא ושיתוף', onPressed: () => exportLessonMenu(context, l)),
                  IconButton(icon: const Icon(Icons.edit_rounded), onPressed: () => go(context, LessonForm(lesson: l))),
                ],
                bottom: TabBar(
                  dividerColor: Colors.transparent,
                  tabs: const [
                    Tab(text: 'סימניות'),
                    Tab(text: 'תמלול'),
                    Tab(text: 'סיכום'),
                    Tab(text: 'נקודות'),
                  ],
                ),
              ),
              body: Column(children: [
                Expanded(
                  child: TabBarView(children: [
                    SegList(l.marks, track, 'סימנייה בנקודה הנוכחית', changed, emptyText: 'הוסף סימניות לרגעים חשובים'),
                    SegList(
                      l.transcript,
                      track,
                      'הוספת שורת תמלול',
                      changed,
                      emptyText: busy ? '' : 'עדיין אין תמלול – לחץ "תמלול אוטומטי"',
                      header: Padding(
                        padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
                        child: Column(children: [
                          Wrap(alignment: WrapAlignment.center, spacing: 4, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
                            SizedBox(
                              width: double.infinity,
                              child: FilledButton.icon(
                                style: FilledButton.styleFrom(minimumSize: const Size(0, 44)),
                                icon: busy
                                    ? SizedBox.square(
                                        dimension: 18,
                                        child: CircularProgressIndicator(strokeWidth: 2, color: c.onPrimary),
                                      )
                                    : const Icon(Icons.auto_awesome_rounded),
                                label: Text(busy ? 'מתמלל...' : 'תמלול אוטומטי'),
                                onPressed: busy ? null : transcribe,
                              ),
                            ),
                            IconButton.filledTonal(
                                tooltip: 'תמלולים מכמה מנועים והשוואה',
                                icon: Badge(
                                  isLabelVisible: l.transcripts.length > 1,
                                  label: Text('${l.transcripts.length}'),
                                  child: const Icon(Icons.compare_arrows_rounded),
                                ),
                                onPressed: busy ? null : () => go(context, TranscriptsScreen(l))),
                            IconButton.filledTonal(
                                tooltip: 'עריכה כטקסט', icon: const Icon(Icons.edit_note_rounded), onPressed: busy ? null : editAsText),
                            IconButton.filledTonal(
                                tooltip: 'העלאת טקסט וסידור לפי זמנים',
                                icon: const Icon(Icons.schedule_rounded),
                                onPressed: busy ? null : alignTextByTime,
                            ),
                            IconButton.filledTonal(
                                tooltip: 'התאמת טקסט לזמנים באמצעות AI',
                                icon: const Icon(Icons.auto_awesome_rounded),
                                onPressed: busy ? null : alignTextWithAI,
                            ),
                            IconButton.filledTonal(
                              tooltip: 'העתקה',
                              icon: const Icon(Icons.copy_rounded),
                              onPressed: l.transcript.isEmpty
                                  ? null
                                  : () {
                                      Clipboard.setData(ClipboardData(text: l.transcript.map((e) => e.text).join('\n')));
                                      snack(context, 'התמלול הועתק');
                                    },
                            ),
                          ]),
                          if (busy)
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Column(children: [
                                const LinearProgressIndicator(),
                                const SizedBox(height: 6),
                                Text(status, style: Theme.of(context).textTheme.bodySmall),
                              ]),
                            )
                          else
                            Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: Text('מנוע: ${Transcriber.provider.label}',
                                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: c.onSurfaceVariant)),
                            ),
                        ]),
                      ),
                    ),
                    Column(children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: TextField(
                            controller: summary,
                            maxLines: null,
                            expands: true,
                            textAlignVertical: TextAlignVertical.top,
                            decoration: const InputDecoration(hintText: 'סיכום השיעור...'),
                            onChanged: (v) {
                              l.summary = v;
                              app.save(notify: false);
                            },
                          ),
                        ),
                      ),
                    ]),
                    _PointsTab(lesson: l),
                  ]),
                ),
                const Divider(),
                SafeArea(top: false, child: PlayerControls(track)),
              ]),
            ),
          );
        },
      );
}


/// לשונית הנקודות בדף השיעור: חיפוש, רשימה, גרירה לשינוי סדר, לחיצה פותחת חלון נקודה.
class _PointsTab extends StatefulWidget {
  final Lesson lesson;
  const _PointsTab({required this.lesson});
  @override
  State<_PointsTab> createState() => _PointsTabState();
}

class _PointsTabState extends State<_PointsTab> {
  String q = '';
  Lesson get l => widget.lesson;

  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    final query = q.trim().toLowerCase();
    final visible = [
      for (var i = 0; i < l.pointCount; i++)
        if (query.isEmpty ||
            l.pointTitle(i).toLowerCase().contains(query) ||
            l.pointNote(i).toLowerCase().contains(query))
          i
    ];
    Widget tile(int i) => ListTile(
          key: ValueKey('pt_${i}_${l.pointStart(i)}_${l.pointTitle(i).hashCode}'),
          onTap: () => showPointDialog(context, l, i),
          leading: CircleAvatar(
            radius: 13,
            backgroundColor: c.primaryContainer,
            child: Text('${i + 1}', style: TextStyle(fontSize: 12, color: c.onPrimaryContainer)),
          ),
          title: Text(l.pointTitle(i), style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${fmt(Duration(milliseconds: l.pointStart(i)))} – ${fmt(Duration(milliseconds: l.pointEnd(i)))}',
                style: TextStyle(color: c.primary)),
            if (l.pointNote(i).isNotEmpty) Text(l.pointNote(i), maxLines: 2, overflow: TextOverflow.ellipsis),
          ]),
          trailing: IconButton(
            tooltip: 'הפעל קטע',
            icon: const Icon(Icons.play_circle_outline_rounded),
            onPressed: () => player.playSegment(Track.lesson(l), l.pointStart(i), l.pointEnd(i)),
          ),
        );
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
        child: Row(children: [
          Expanded(
            child: TextField(
              decoration: const InputDecoration(
                  isDense: true, prefixIcon: Icon(Icons.search_rounded), hintText: 'חיפוש בנקודות'),
              onChanged: (v) => setState(() => q = v),
            ),
          ),
          const SizedBox(width: 10),
          Text('${l.pointCount} נקודות', style: TextStyle(color: c.primary, fontWeight: FontWeight.w700)),
        ]),
      ),
      Expanded(
        child: l.pointCount == 0
            ? Center(child: Text('אין עדיין נקודות', style: TextStyle(color: c.onSurfaceVariant)))
            : query.isNotEmpty
                ? (visible.isEmpty
                    ? Center(child: Text('לא נמצאו נקודות', style: TextStyle(color: c.onSurfaceVariant)))
                    : ListView(padding: const EdgeInsets.all(8), children: [for (final i in visible) tile(i)]))
                : ReorderableListView(
                    padding: const EdgeInsets.all(8),
                    onReorder: (a, b) {
                      if (b > a) b--;
                      l.movePoint(a, b);
                      app.save();
                    },
                    children: [for (var i = 0; i < l.pointCount; i++) tile(i)],
                  ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
        child: FilledButton.icon(
          style: FilledButton.styleFrom(minimumSize: const Size(double.infinity, 46)),
          icon: const Icon(Icons.add_rounded),
          label: Text(player.isCurrent(l.id) ? 'הוסף נקודה מהשנייה הנוכחית' : 'הוסף נקודה'),
          onPressed: () => showAddPointDialog(context, l),
        ),
      ),
    ]);
  }
}
