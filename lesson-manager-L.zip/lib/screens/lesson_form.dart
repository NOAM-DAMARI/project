import '../services/file_service.dart';
import '../services/media_upload.dart';
import '../models/lesson.dart';
import '../services/app_state.dart';
import '../utils/helpers.dart';
import '../widgets/hebrew_date_picker.dart';
import 'package:flutter/material.dart';

class LessonForm extends StatefulWidget {
  final Lesson? lesson;
  const LessonForm({super.key, this.lesson});
  @override
  State<LessonForm> createState() => _LessonFormState();
}

class _LessonFormState extends State<LessonForm> {
  late final title = TextEditingController(text: widget.lesson?.title);
  late final lecturer = TextEditingController(text: widget.lesson?.lecturer);
  late final notes = TextEditingController(text: widget.lesson?.notes);
  late DateTime date = widget.lesson?.date ?? DateTime.now();
  PickedMedia? picked;
  bool saving = false;

  @override
  void dispose() {
    title.dispose();
    lecturer.dispose();
    notes.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    if (title.text.trim().isEmpty) {
      snack(context, 'יש להזין שם לשיעור');
      return;
    }
    setState(() => saving = true);
    final isNew = widget.lesson == null;
    final l = widget.lesson ?? Lesson(id: app.newId(), title: '');
    l
      ..title = title.text.trim()
      ..lecturer = lecturer.text.trim()
      ..notes = notes.text
      ..date = date;
    if (picked != null) {
      final ok = await attachMedia(context, l, picked!, folder: 'lessons');
      if (!ok) {
        if (mounted) setState(() => saving = false);
        return;
      }
      app.prefs.remove('pos_${l.id}');
    }
    if (l.lecturer.isNotEmpty) app.addLecturer(l.lecturer);
    if (isNew) app.lessons.add(l);
    app.save();
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    final currentName = picked?.name ?? widget.lesson?.fileName;
    final currentSize = picked?.size ?? widget.lesson?.fileSize;
    return Scaffold(
      appBar: AppBar(title: Text(widget.lesson == null ? 'שיעור חדש' : 'עריכת שיעור'), actions: [
        if (widget.lesson != null)
          IconButton(
              icon: const Icon(Icons.delete_outline_rounded),
              onPressed: () async {
                if (await confirm(context, 'למחוק את השיעור?')) {
                  app.deleteLesson(widget.lesson!);
                  if (context.mounted) {
                    Navigator.pop(context);
                    Navigator.pop(context);
                  }
                }
              }),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(
            controller: title, decoration: const InputDecoration(labelText: 'שם השיעור', prefixIcon: Icon(Icons.school_rounded))),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: DropdownMenu<String>(
              key: ValueKey(app.lecturers.join('|')),
              controller: lecturer,
              expandedInsets: EdgeInsets.zero,
              label: const Text('מרצה'),
              hintText: 'בחר מהרשימה או הקלד שם חדש',
              leadingIcon: const Icon(Icons.person_rounded),
              enableFilter: true,
              enableSearch: true,
              requestFocusOnTap: true,
              dropdownMenuEntries: {
                ...app.lecturers,
                if (widget.lesson?.lecturer.trim().isNotEmpty == true) widget.lesson!.lecturer.trim(),
              }.map((name) => DropdownMenuEntry<String>(value: name, label: name)).toList(),
              onSelected: (value) {
                if (value != null) lecturer.text = value;
              },
            ),
          ),
          IconButton(
            tooltip: 'ניהול רשימת המרצים',
            icon: const Icon(Icons.manage_accounts_rounded),
            onPressed: () async {
              await _manageLecturers(context);
              if (mounted) setState(() {});
            },
          ),
        ]),
        const SizedBox(height: 12),
        Card(
          child: ListTile(
            leading: Icon(Icons.event_rounded, color: c.primary),
            title: Text(fmtDate(date)),
            subtitle: Text(hebrewDate(date)),
            trailing: const Icon(Icons.edit_calendar_rounded),
            onTap: () async {
              final d = await pickAnyDate(context, date);
              if (d != null) setState(() => date = d);
            },
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: ListTile(
            leading: Icon(currentName == null ? Icons.upload_file_rounded : Icons.audio_file_rounded, color: c.primary),
            title: Text(currentName ?? 'העלאת הקלטה (שמע / וידאו)'),
            subtitle: Text(currentName == null
                ? 'MP3, M4A, MP4 ועוד · עד 2GB'
                : [fmtBytes(currentSize), if (picked != null) 'יועלה בשמירה'].where((e) => e.isNotEmpty).join(' · ')),
            trailing: TextButton(
              onPressed: saving
                  ? null
                  : () async {
                      final f = await pickAudio();
                      if (f != null) setState(() => picked = f);
                    },
              child: Text(currentName == null ? 'בחירה' : 'החלפה'),
            ),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
            controller: notes, maxLines: 3, decoration: const InputDecoration(labelText: 'הערות', alignLabelWithHint: true)),
        const SizedBox(height: 20),
        FilledButton(onPressed: saving ? null : submit, child: Text(saving ? 'שומר...' : 'שמירה')),
      ]),
    );
  }
}


/// עריכת רשימת המרצים (רשימה פשוטה, לא ישות נפרדת): הוספה, שינוי שם, הסרה מהרשימה.
Future<void> _manageLecturers(BuildContext context) => showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) {
          final names = app.lecturers;
          return AlertDialog(
            title: const Text('רשימת המרצים'),
            content: SizedBox(
              width: 420,
              child: names.isEmpty
                  ? const Text('אין עדיין מרצים ברשימה')
                  : ListView(shrinkWrap: true, children: [
                      for (final n in names)
                        ListTile(
                          title: Text(n),
                          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                            IconButton(
                                tooltip: 'שינוי שם (מעדכן גם בשיעורים)',
                                icon: const Icon(Icons.edit_outlined),
                                onPressed: () async {
                                  final t = await askText(ctx, 'שינוי שם מרצה', init: n);
                                  if (t != null) setD(() => app.renameLecturer(n, t));
                                }),
                            IconButton(
                                tooltip: 'הסרה מהרשימה',
                                icon: const Icon(Icons.delete_outline_rounded),
                                onPressed: () => setD(() => app.removeLecturer(n))),
                          ]),
                        ),
                    ]),
            ),
            actions: [
              TextButton.icon(
                icon: const Icon(Icons.add_rounded),
                label: const Text('הוספת מרצה'),
                onPressed: () async {
                  final t = await askText(ctx, 'מרצה חדש');
                  if (t != null) setD(() => app.addLecturer(t));
                },
              ),
              FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('סגור')),
            ],
          );
        },
      ),
    );
