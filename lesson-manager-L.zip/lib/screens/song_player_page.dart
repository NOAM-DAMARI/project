import 'playlists_screen.dart';
import '../models/song.dart';
import '../services/app_state.dart';
import '../services/player_service.dart';
import '../utils/helpers.dart';
import '../widgets/player_controls.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'song_form.dart';
import '../services/text_aligner.dart';
import '../services/transcriber.dart';

class SongPlayerPage extends StatefulWidget {
  final Song s;
  const SongPlayerPage(this.s, {super.key});
  @override
  State<SongPlayerPage> createState() => _SongPlayerState();
}

class _SongPlayerState extends State<SongPlayerPage> {
  Song get s => widget.s;
  late List<String> lines;
  int active = -1;
  bool syncing = false;
  double fontScale = 1;
  StreamSubscription? sub;

  @override
  void initState() {
    super.initState();
    _prepareLines();
    player.markFullScreen(s.id, true);
    sub = player.p.positionStream.listen((pos) {
      if (!player.isCurrent(s.id)) return;
      int best = -1, bestMs = -1;
      for (var i = 0; i < lines.length; i++) {
        final t = s.stamps[i];
        if (t >= 0 && t <= pos.inMilliseconds && t > bestMs) {
          best = i;
          bestMs = t;
        }
      }
      if (best != active && mounted) {
        setState(() => active = best);

      }
    });
  }

  void _prepareLines() {
    lines = s.lyrics.split('\n');
    while (s.stamps.length < lines.length) {
      s.stamps.add(-1);
    }
    if (s.stamps.length > lines.length) s.stamps.removeRange(lines.length, s.stamps.length);
  }

  @override
  void dispose() {
    sub?.cancel();
    player.markFullScreen(s.id, false);
    super.dispose();
  }

  int get _now => player.isCurrent(s.id) ? player.p.position.inMilliseconds : -1;

  void stamp(int i) {
    final ms = _now;
    if (ms < 0) {
      snack(context, 'הפעל קודם את השיר');
      return;
    }
    s.stamps[i] = ms;
    app.save();
    setState(() {});
  }

  bool aligning = false;

  /// מילים מדויקות + תמלול אוטומטי של השיר לקבלת זמנים → זמן לכל שורה, בלי לשנות את המילים.
  Future<void> _alignLyrics() async {
    if (!s.hasMedia) {
      snack(context, 'יש להעלות קודם קובץ שמע לשיר');
      return;
    }
    if (!Transcriber.ready) {
      snack(context, 'יש להגדיר מנוע תמלול בהגדרות – הזמנים נלקחים מהתמלול');
      return;
    }
    final text = await askTextForAlignment(context, title: 'מילים לשיר – סידור לפי זמנים');
    if (text == null || !mounted) return;
    setState(() => aligning = true);
    try {
      final timed = await Transcriber.transcribe(s);
      final aligned = TextAligner.align(text, timed);
      s.lyrics = text.split(RegExp(r'\r?\n')).where((e) => e.trim().isNotEmpty).join('\n');
      s.stamps = [for (final a in aligned) a.ms];
      app.save();
      if (mounted) {
        setState(_prepareLines);
        snack(context, 'המילים סודרו לפי הזמנים');
      }
    } catch (e) {
      if (mounted) snack(context, 'הסידור נכשל: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => aligning = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final sg = app.singer(s.singerId);
    final c = Theme.of(context).colorScheme;
    final accent = sg != null ? Color(sg.color) : c.primary;
    final synced = s.stamps.where((x) => x >= 0).length;

    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(s.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          if (sg != null) Text(sg.name, style: TextStyle(fontSize: 13, color: c.onSurfaceVariant)),
        ]),
        actions: [
          IconButton(
            icon: Icon(syncing ? Icons.check_circle_rounded : Icons.timer_outlined),
            tooltip: syncing ? 'סיום סנכרון מילים' : 'סנכרון מילים לשיר',
            onPressed: s.lyrics.isEmpty ? null : () => setState(() => syncing = !syncing),
          ),
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'playlist') addToPlaylist(context, s);
              if (v == 'edit') {
                await go(context, SongForm(song: s));
                if (mounted) setState(_prepareLines);
              }
              if (v == 'align') await _alignLyrics();
              if (v == 'bigger') setState(() => fontScale = (fontScale + .15).clamp(.7, 2.0));
              if (v == 'smaller') setState(() => fontScale = (fontScale - .15).clamp(.7, 2.0));
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'playlist', child: Text('הוספה לרשימת השמעה')),
              PopupMenuItem(value: 'edit', child: Text('עריכת שיר')),
              PopupMenuItem(value: 'align', child: Text('העלאת טקסט וסידור לפי זמנים')),
              PopupMenuItem(value: 'bigger', child: Text('הגדלת טקסט')),
              PopupMenuItem(value: 'smaller', child: Text('הקטנת טקסט')),
            ],
          ),
        ],
      ),
      body: Column(children: [
        if (aligning) const LinearProgressIndicator(),
        Expanded(
          child: s.lyrics.isEmpty
              ? Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      width: 160,
                      height: 160,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [accent, accent.withValues(alpha: .5)]),
                        borderRadius: BorderRadius.circular(32),
                      ),
                      child: const Icon(Icons.music_note_rounded, size: 72, color: Colors.white),
                    ),
                    const SizedBox(height: 16),
                    Text('אין מילים לשיר הזה', style: TextStyle(color: c.onSurfaceVariant)),
                  ]),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                  itemCount: lines.length,
                  itemBuilder: (_, i) {
                    final isActive = i == active;
                    final hasStamp = s.stamps[i] >= 0;
                    return InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: () {
                        if (syncing) {
                          stamp(i);
                        } else if (hasStamp) {
                          player.seekTo(Track.song(s), s.stamps[i]);
                        }
                      },
                      onLongPress: syncing
                          ? () {
                              s.stamps[i] = -1;
                              app.save();
                              setState(() {});
                            }
                          : null,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                        child: Row(children: [
                          Expanded(
                            child: AnimatedDefaultTextStyle(
                              duration: const Duration(milliseconds: 250),
                              style: TextStyle(
                                fontFamily: Theme.of(context).textTheme.bodyLarge?.fontFamily,
                                fontSize: (isActive ? 24 : 19) * fontScale,
                                height: 1.4,
                                fontWeight: isActive ? FontWeight.w800 : FontWeight.w500,
                                color: isActive
                                    ? accent
                                    : (active >= 0 ? c.onSurface.withValues(alpha: .55) : c.onSurface),
                              ),
                              child: Text(lines[i]),
                            ),
                          ),
                          if (syncing)
                            hasStamp
                                ? Text(fmt(Duration(milliseconds: s.stamps[i])),
                                    style: TextStyle(fontSize: 12, color: c.primary, fontWeight: FontWeight.w700))
                                : Icon(Icons.radio_button_unchecked, size: 14, color: c.outline),
                        ]),
                      ),
                    );
                  },
                ),
        ),
        if (syncing)
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 12),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: c.primaryContainer.withValues(alpha: .5), borderRadius: BorderRadius.circular(16)),
            child: Column(children: [
              Text('נגן את השיר ולחץ "הצמד" בתחילת כל שורה ($synced/${lines.where((l) => l.trim().isNotEmpty).length}). '
                  'לחיצה על שורה = הצמדה ידנית, לחיצה ארוכה = ניקוי.',
                  textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 8),
              FilledButton.icon(
                style: FilledButton.styleFrom(minimumSize: const Size(double.infinity, 46)),
                icon: const Icon(Icons.push_pin_rounded),
                label: const Text('הצמד לשורה הבאה'),
                onPressed: () {
                  final n = [
                    for (var i = 0; i < lines.length; i++)
                      if (s.stamps[i] < 0 && lines[i].trim().isNotEmpty) i
                  ];
                  if (n.isNotEmpty) stamp(n.first);
                },
              ),
            ]),
          ),
        SafeArea(top: false, child: PlayerControls(Track.song(s))),
      ]),
    );
  }
}
