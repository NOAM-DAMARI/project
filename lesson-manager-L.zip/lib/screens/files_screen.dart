import '../models/lesson.dart';
import '../models/media.dart';
import '../models/song.dart';
import '../services/file_service.dart';
import '../services/github_media.dart';
import '../services/media_resolver.dart';
import '../services/media_upload.dart';
import '../services/app_state.dart';
import '../services/storage.dart';
import '../services/player_service.dart';
import '../services/download_bytes.dart';
import '../utils/helpers.dart';
import '../widgets/ui.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class FilesScreen extends StatefulWidget {
  const FilesScreen({super.key});
  @override
  State<FilesScreen> createState() => _FilesScreenState();
}

class _FilesScreenState extends State<FilesScreen> {
  final Map<MediaFields, double?> downloading = {};

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (context, _) {
          final songs = app.songs.where((s) => s.hasMedia).toList();
          final lessons = app.lessons.where((s) => s.hasMedia).toList();
          final total = [...songs, ...lessons].fold<int>(0, (s, m) => s + (m.fileSize ?? 0));
          return Scaffold(
            appBar: AppBar(title: const Text('קבצים')),
            body: songs.isEmpty && lessons.isEmpty
                ? const EmptyState(
                    icon: Icons.folder_open_rounded,
                    title: 'אין קבצים',
                    subtitle: 'קבצי שמע שתעלה לשירים ולשיעורים יופיעו כאן',
                  )
                : ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), children: [
                    Text('${songs.length + lessons.length} קבצים · ${fmtBytes(total)}',
                        style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                    if (songs.isNotEmpty) ...[
                      const SectionTitle('שירים'),
                      Card(child: Column(children: [for (final s in songs) _tile(s, s.title, 'songs')])),
                    ],
                    if (lessons.isNotEmpty) ...[
                      const SectionTitle('שיעורים'),
                      Card(child: Column(children: [for (final l in lessons) _tile(l, l.title, 'lessons')])),
                    ],
                  ]),
          );
        },
      );

  Widget _tile(MediaFields m, String title, String folder) {
    final c = Theme.of(context).colorScheme;
    final onDevice = localFileExists(m.filePath);
    final offline = MediaResolver.isOffline(m);
    final dl = downloading.containsKey(m);
    return ListTile(
      leading: Icon(Icons.audio_file_rounded, color: c.primary),
      title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text([m.fileName ?? '', fmtBytes(m.fileSize)].where((e) => e.isNotEmpty).join(' · '),
            maxLines: 1, overflow: TextOverflow.ellipsis),
        const SizedBox(height: 4),
        Wrap(spacing: 6, children: [
          if (m.isInCloud) const Pill('בענן', icon: Icons.cloud_done_rounded),
          if (offline) Pill('במכשיר', icon: Icons.phone_android_rounded, color: c.tertiary),
          if (!m.isInCloud && !onDevice) Pill('חסר במכשיר הזה', icon: Icons.warning_amber_rounded, color: c.error),
        ]),
        if (dl) Padding(padding: const EdgeInsets.only(top: 6), child: LinearProgressIndicator(value: downloading[m])),
      ]),
      isThreeLine: true,
      trailing: PopupMenuButton<String>(
        onSelected: (v) => _action(v, m, folder),
        itemBuilder: (_) => [
          const PopupMenuItem(value: 'play', child: Text('השמעה מקדימה')),
          if (kIsWeb && m.remoteUrl != null) const PopupMenuItem(value: 'web', child: Text('הורדה למחשב')),
          if (m.isInCloud && !offline && !kIsWeb) const PopupMenuItem(value: 'download', child: Text('שמירה במכשיר')),
          if (offline && !onDevice) const PopupMenuItem(value: 'unoffline', child: Text('הסרה מהמכשיר')),
          if (!m.isInCloud && onDevice && app.githubReady) const PopupMenuItem(value: 'upload', child: Text('העלאה ל-GitHub')),
          const PopupMenuItem(value: 'replace', child: Text('החלפת קובץ')),
          const PopupMenuItem(value: 'delete', child: Text('מחיקת הקובץ')),
        ],
      ),
    );
  }

  Future<void> _action(String v, MediaFields m, String folder) async {
    switch (v) {
      case 'play':
        final track = m is Song ? Track.song(m) : Track.lesson(m as Lesson);
        await player.open(track);
        return;
      case 'web':
        await openDownloadUrl(m.remoteUrl!, m.fileName ?? 'media');
        return;
      case 'download':
        setState(() => downloading[m] = null);
        try {
          await MediaResolver.ensureLocal(m, onProgress: (g, t) {
            if (mounted && t != null) setState(() => downloading[m] = g / t);
          });
          if (mounted) snack(context, 'נשמר במכשיר להאזנה ללא אינטרנט');
        } catch (e) {
          if (mounted) snack(context, 'ההורדה נכשלה: $e');
        }
        if (mounted) setState(() => downloading.remove(m));
      case 'unoffline':
        await MediaResolver.removeOffline(m);
        setState(() {});
      case 'upload':
        if (await uploadExisting(context, m, folder: folder)) app.save();
      case 'replace':
        final f = await pickAudio();
        if (f == null || !mounted) return;
        await MediaResolver.removeOffline(m);
        if (await attachMedia(context, m, f, folder: folder)) {
          if (m is Lesson) app.prefs.remove('pos_${m.id}');
          if (m is Song) m.stamps = [];
          app.save();
        }
      case 'delete':
        if (!await confirm(context, 'למחוק את הקובץ? השיר/השיעור עצמו יישאר.')) return;
        await MediaResolver.removeOffline(m);
        await deleteMedia(m.filePath);
        if (m.assetApi != null && app.githubReady) {
          GitHubMedia.deleteAsset(m.assetApi!).catchError((_) {});
        }
        m.clearMedia();
        app.save();
    }
  }
}
