import 'package:flutter/material.dart';

import '../models/lesson.dart';
import '../services/app_state.dart';
import '../services/player_service.dart';
import '../services/points.dart';
import '../utils/helpers.dart';
import '../widgets/point_dialog.dart';
import '../widgets/ui.dart';

/// מרכז נקודות גלובלי: כל הנקודות מכל השיעורים, עם חיפוש, ניגון קטע, עריכה ומחיקה.
class PointsScreen extends StatefulWidget {
  const PointsScreen({super.key});
  @override
  State<PointsScreen> createState() => _PointsScreenState();
}

class _PointsScreenState extends State<PointsScreen> {
  String query = '';
  String sort = 'lesson';

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (context, _) {
          final q = query.trim().toLowerCase();
          bool has(String s) => s.toLowerCase().contains(q);
          final items = <({Lesson lesson, int index})>[
            for (final lesson in app.lessons)
              for (var i = 0; i < lesson.pointCount; i++)
                if (q.isEmpty || has(lesson.pointTitle(i)) || has(lesson.pointNote(i)) || has(lesson.title) || has(lesson.lecturer))
                  (lesson: lesson, index: i),
          ];
          if (sort == 'title') {
            items.sort((a, b) => a.lesson.pointTitle(a.index).compareTo(b.lesson.pointTitle(b.index)));
          } else if (sort == 'date') {
            items.sort((a, b) => b.lesson.date.compareTo(a.lesson.date));
          }
          final c = Theme.of(context).colorScheme;
          return Scaffold(
            appBar: AppBar(title: Text('מרכז נקודות (${items.length})')),
            body: Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                child: SearchField(
                    hint: 'חיפוש בכותרת, פירוט, שיעור או מרצה', onChanged: (value) => setState(() => query = value)),
              ),
              SizedBox(
                height: 44,
                child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
                  for (final e in {'lesson': 'לפי שיעור', 'date': 'תאריך שיעור', 'title': 'כותרת'}.entries)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 6),
                      child: ChoiceChip(
                          label: Text(e.value), selected: sort == e.key, onSelected: (_) => setState(() => sort = e.key)),
                    ),
                ]),
              ),
              Expanded(
                child: items.isEmpty
                    ? Center(
                        child: Text(q.isEmpty ? 'עדיין אין נקודות' : 'לא נמצאו נקודות',
                            style: TextStyle(color: c.onSurfaceVariant)))
                    : ListView.separated(
                        padding: const EdgeInsets.all(12),
                        itemCount: items.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 6),
                        itemBuilder: (context, position) {
                          final lesson = items[position].lesson;
                          final i = items[position].index;
                          final start = lesson.pointStart(i), end = lesson.pointEnd(i);
                          return Card(
                            child: ListTile(
                              onTap: () => showPointDialog(context, lesson, i),
                              leading: ListenableBuilder(
                                listenable: player,
                                builder: (_, __) {
                                  final active = player.isCurrent(lesson.id) && player.segmentEndMs != null;
                                  return IconButton(
                                    tooltip: active ? 'עצירה' : 'הפעל קטע',
                                    icon: Icon(active ? Icons.stop_circle_outlined : Icons.play_circle_outline_rounded),
                                    onPressed: () async {
                                      if (active) {
                                        await player.p.pause();
                                        player.cancelSegment();
                                      } else {
                                        await player.playSegment(Track.lesson(lesson), start, end);
                                      }
                                    },
                                  );
                                },
                              ),
                              title: Text(lesson.pointTitle(i), style: const TextStyle(fontWeight: FontWeight.w700)),
                              subtitle: Text(
                                '${lesson.title} · ${fmt(Duration(milliseconds: start))}–${fmt(Duration(milliseconds: end))}'
                                '${lesson.pointNote(i).isEmpty ? '' : '\n${lesson.pointNote(i)}'}',
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                              ),
                              trailing: PopupMenuButton<String>(
                                onSelected: (v) async {
                                  if (v == 'edit') showPointDialog(context, lesson, i, startEditing: true);
                                  if (v == 'delete' && await confirm(context, 'למחוק את הנקודה "${lesson.pointTitle(i)}"?')) {
                                    lesson.removePoint(i);
                                    app.save();
                                  }
                                },
                                itemBuilder: (_) => const [
                                  PopupMenuItem(value: 'edit', child: Text('עריכה')),
                                  PopupMenuItem(value: 'delete', child: Text('מחיקה')),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ]),
          );
        },
      );
}
