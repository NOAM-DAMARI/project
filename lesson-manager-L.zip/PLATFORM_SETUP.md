# הקמת הפרויקט

1. גבה את התיקייה, ואז הרץ `./setup.sh` (או `setup.bat` ב-Windows).
   הפקודה `flutter create --platforms=android,ios,web .` מוסיפה את `android/`, `ios/`, `web/` בגרסה המתאימה ל-SDK שלך, ואינה מוחקת את `lib/` ואת `pubspec.yaml` הקיימים.
2. הוסף הרשאות כמפורט למטה.
3. `flutter run`

## Android — `android/app/src/main/AndroidManifest.xml`
בתוך `<manifest>`, לפני `<application>`:
```xml
<uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
<uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
```
ודא ב-`android/app/build.gradle` (או `.kts`) ש-`minSdk` הוא 21 לפחות (נדרש ל-just_audio).

## iOS — `ios/Runner/Info.plist`
בתוך `<dict>`:
```xml
<key>NSPhotoLibraryUsageDescription</key>
<string>בחירת תמונות של זמרים</string>
<key>NSAppleMusicUsageDescription</key>
<string>בחירת קבצי שמע</string>
<key>UIBackgroundModes</key>
<array><string>audio</string></array>
```

## Web
האפליקציה משתמשת ב-`dart:io` (העתקת קבצים, `File`), ולכן לא תתקמפל ל-web כמו שהיא. כדי לתמוך ב-web צריך להחליף את `file_service.dart` ואת הצגת התמונות בגרסה שעובדת עם bytes, ואת האחסון במסד נתונים של הדפדפן.
