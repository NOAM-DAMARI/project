@echo off
flutter create --platforms=android,ios,web --project-name music_manager .
flutter pub get
echo Now update permissions per PLATFORM_SETUP.md, then: flutter run
